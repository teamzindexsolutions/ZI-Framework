<?php

if ( function_exists( 'add_theme_support' ) ) {
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 300, 300, true );
}

add_action( 'init', 'team_register' );  

function team_register() {
    $labels = array(
        'name' => __( 'Team', 'konvers' ),
        'add_new' => __( 'Add New', 'konvers' ),
        'add_new_item' => __( 'Add New Team Member', 'konvers' ),
        'edit_item' => __( 'Edit Team Member', 'konvers' ),
        'new_item' => __( 'New Team Member', 'konvers' ),
        'view_item' => __( 'View Team Member', 'konvers' ),
        'search_items' => __( 'Search Team Members', 'konvers' ),
        'not_found' => __( 'No items found', 'konvers' ),
        'not_found_in_trash' => __( 'No items found in Trash', 'konvers' ), 
        'parent_item_colon' => '',
        'menu_name' => 'Team'
        );
    
    $args = array(
        'labels' => $labels,
        'menu_icon' => 'dashicons-businessman',
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'rewrite' => array( 'slug' => 'profile', 'with_front' => false ),
        'exclude_from_search' => true,
        'supports' => array( 'title', 'editor', 'thumbnail', 'page-attributes' )
       );  

    register_post_type( 'team' , $args );
}

add_action( 'contextual_help', 'team_help_text', 10, 3 );

function team_help_text( $contextual_help, $screen_id, $screen ) {
    if ( 'team' == $screen->id ) {
        $contextual_help =
        '<h3>' . __( 'Things to remember when adding a Team Member:', 'konvers' ) . '</h3>' .
        '<ul>' .
        '<li>' . __( 'Add your team member name. (ie; John Smith).', 'konvers' ) . '</li>' .
        '<li>' . __( 'Add a featured image (headshot possibly) for your team member.', 'konvers' ) . '</li>' .
        '<li>' . __( 'Add a job title for your team member. (ie; The Boss or Managing Director).', 'konvers' ) . '</li>' .
        '<li>' . __( 'Add any Social Networks your Team Member belongs to. (ie; Twitter, Linkedin etc...).', 'konvers' ) . '</li>' .
        '</ul>';
    }
    elseif ( 'edit-team' == $screen->id ) {
        $contextual_help = '<p>' . __( 'A list of all team members appear below. To edit a member, click on the Team Member name.', 'konvers' ) . '</p>';
    }
    return $contextual_help;
}

function team_image_box() {
	remove_meta_box( 'postimagediv', 'team', 'side' );
	add_meta_box( 'postimagediv', __( 'Team Member Image', 'konvers' ), 'post_thumbnail_meta_box', 'team', 'side', 'low' );
}
add_action( 'do_meta_boxes', 'team_image_box' );

add_filter( 'manage_edit-team_columns', 'team_edit_columns' );

function team_edit_columns( $columns ) {
        $columns = array(
            'cb' => '<input type=\'checkbox\' />',
            'title' => 'Team Member Name',
        );  

        return $columns;
}
 
function team_save_order() {
    global $wpdb;
 
    $order = explode( ',', $_POST['order'] );
    $counter = 0;
 
    foreach ( $order as $post_id ) {
        $wpdb->update($wpdb->posts, array( 'menu_order' => $counter ), array( 'ID' => $post_id) );
        $counter++;
    }
    die( 1 );
}
add_action( 'wp_ajax_post_sort', 'team_save_order' );

/*-----------------------------------------------------------------------------------*/
/*	Define Metabox Fields
/*-----------------------------------------------------------------------------------*/

$prefix = 'gt_';
 
$meta_box_team = array(
	'id' => 'team_member',
    'title' => __( 'Team Member Details', 'konvers' ),
    'page' => 'team',
    'context' => 'normal',
    'priority' => 'high',
    'fields' => array(
    	array(
    		'name' =>  __( 'Member Role', 'konvers' ),
    	    'desc' => __( 'Enter a role for the Team Member <br />(ie; Creative Director)', 'konvers' ),
    	    'id' => $prefix . 'member_role',
    	    'type' => 'text',
    	    'std' => ''
    	),
        array(
           'name' => __( 'Twitter', 'konvers' ),
           'desc' => __( 'Enter your Twitter Profile URL <br />(ie; http://twitter.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_twitter',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Facebook', 'konvers' ),
           'desc' => __( 'Enter your Facebook Profile URL <br />(ie; http://facebook.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_facebook',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Google Plus', 'konvers' ),
           'desc' => __( 'Enter your Google + Profile URL <br />(ie; http://plus.google.com/+guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_googleplus',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Tumblr', 'konvers' ),
           'desc' => __( 'Enter your Tumblr Profile URL <br />(ie; http://guuthemes.tumblr.com)', 'konvers' ),
           'id' => $prefix . 'member_tumblr',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Linkedin', 'konvers' ),
           'desc' => __( 'Enter your Linkedin Profile URL <br />(ie; http://linkedin.com/in/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_linkedin',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Behance', 'konvers' ),
           'desc' => __( 'Enter your Behance Profile URL <br />(ie; http://behance.net/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_behance',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Pinterest', 'konvers' ),
           'desc' => __( 'Enter your Pinterest Profile URL <br />(ie; http://pinterest.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_pinterest',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Dribbble', 'konvers' ),
           'desc' => __( 'Enter your Dribbble Profile URL <br />(ie; http://dribbble.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_dribbble',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Flickr', 'konvers' ),
           'desc' => __( 'Enter your Flickr Profile URL <br />(ie; http://flickr.com/photos/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_flickr',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Instagram', 'konvers' ),
           'desc' => __( 'Enter your Instagram Profile URL <br />(ie; http://instagram.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_instagram',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Picasa', 'konvers' ),
           'desc' => __( 'Enter your Picasa Profile URL <br />(ie; http://picasaweb.google.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_picasa',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'DeviantArt', 'konvers' ),
           'desc' => __( 'Enter your DeviantArt Profile URL <br />(ie; http://guuthemes.deviantart.com)', 'konvers' ),
           'id' => $prefix . 'member_deviantart',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'Vimeo', 'konvers' ),
           'desc' => __( 'Enter your Vimeo Profile URL <br />(ie; http://vimeo.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_vimeo',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'YouTube', 'konvers' ),
           'desc' => __( 'Enter your YouTube Profile URL <br />(ie; http://youtube.com/user/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_youtube',
           'type' => 'text',
           'std' => ''
        ),
        array(
           'name' => __( 'SoundCloud', 'konvers' ),
           'desc' => __( 'Enter your SoundCloud Profile URL <br />(ie; https://soundcloud.com/guuthemes)', 'konvers' ),
           'id' => $prefix . 'member_soundcloud',
           'type' => 'text',
           'std' => ''
        )
    )
);

add_action( 'admin_menu', 'gt_add_box_team' );

/*-----------------------------------------------------------------------------------*/
/*	Callback function to show fields in meta box
/*-----------------------------------------------------------------------------------*/

function gt_show_box_team() {
    global $meta_box_team, $post;
	
	// Use nonce for verification
	echo '<input type="hidden" name="gt_add_box_team_nonce" value="', wp_create_nonce( basename( __FILE__ ) ), '" />';

	echo '<table class="form-table">';
		
	foreach ( $meta_box_team['fields'] as $field ) {
		// get current post meta data
		$meta = get_post_meta( $post->ID, $field['id'], true );
			
			echo '<tr style="border-bottom:1px solid #eeeeee;">',
				'<th style="width:25%; font-weight: normal;"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><p style=" display:block; color:#666; margin:5px 0 0 0; line-height: 18px;">'. $field['desc'].'</p></label></th>',
				'<td>';
			echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
			echo '</td></tr>';
		
		}
		
		echo '</table>';
}

add_action( 'save_post', 'gt_save_data_team' );

/*-----------------------------------------------------------------------------------*/
/*	Add metabox to edit page
/*-----------------------------------------------------------------------------------*/
 
function gt_add_box_team() {
	global $meta_box_team;
	
	add_meta_box( $meta_box_team['id'], $meta_box_team['title'], 'gt_show_box_team', $meta_box_team['page'], $meta_box_team['context'], $meta_box_team['priority'] );
	
}

/*-----------------------------------------------------------------------------------*/
/*	Save data when post is edited
/*-----------------------------------------------------------------------------------*/

// Save data from meta box
function gt_save_data_team( $post_id ) {
    global $meta_box_team;

    // verify nonce
    if ( !isset( $_POST['gt_add_box_team_nonce'] ) || !wp_verify_nonce( $_POST['gt_add_box_team_nonce'], basename( __FILE__ ) ) ) {
    	return $post_id;
    }

    // check autosave
    if (defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE) {
        return $post_id;
    }

    // check permissions
    if ( 'page' == $_POST['post_type'] ) {
        if ( !current_user_can( 'edit_page', $post_id ) ) {
            return $post_id;
        }
    } elseif ( !current_user_can( 'edit_post', $post_id ) ) {
        return $post_id;
    }

    foreach ( $meta_box_team['fields'] as $field ) { // save each option
        $old = get_post_meta( $post_id, $field['id'], true );
        $new = $_POST[$field['id']];

        if ( $new && $new != $old ) { // compare changes to existing values
            update_post_meta( $post_id, $field['id'], $new );
        } elseif ( '' == $new && $old ) {
            delete_post_meta( $post_id, $field['id'], $old );
        }
    }
    
}

?>