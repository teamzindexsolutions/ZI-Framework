Please find usage instructions in the included documentation.
Visit us at:
http://bonfirethemes.com/
https://twitter.com/BonfireThemes